import { Link } from 'react-router-dom';

function Home() {
    return (
      <div className = 'Home'>
        <h3 className='Component__title'>Welcome, </h3>
        <div className='Home__description'>
          <p>
            Companies may register to receive a customized smart contract, which will serve
            as a registry of all products produced by the company. This smart contract will
            be made publicly accessible, allowing any individual to verify the authenticity
            of a product by checking its presence on the corresponding smart contract.<br/>
            <span className="Home__warning">Note: Only contract owners can add customer details to their contract</span>
          </p>
        </div>
          <div className='Home__instructions'>
           
          </div>
      </div>
    );
  }
  
export default Home;
